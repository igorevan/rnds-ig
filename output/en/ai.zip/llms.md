# br.gov.saude.rnds.fhir#1.0.0-release: Guia de Implementação da Rede Nacional de Dados em Saúde (RNDS)(en)

## Pages

* [Principal](index.md)
* [Credenciamento](credenciamento.md)
* [Downloads](downloads.md)
* [Suporte da RNDS](suporte.md)
* [Feedback](forms.md)
* [Integração](integracao.md)
* [Artefatos](artifacts.md)
* [Histórico de mudanças](changes.md)

## Resources

### CapabilityStatements

* [CapabilityStatement do EHR-Services da RNDS](CapabilityStatement-CapabilityStatement-EHRServices.md)

### ImplementationGuides

* [Guia de Implementação da Rede Nacional de Dados em Saúde (RNDS)](ImplementationGuide-br.gov.saude.rnds.fhir.md)
